#In Views.py we add all routes there
from flask import Flask,make_response,request,render_template,redirect,url_for,flash
from .form import LoginForm,SignupForm
from app import app,db
from .models import UserInfo
from flask_login import login_user,logout_user,current_user

@app.route('/')
def Index():

    return render_template('index.html')

@app.route("/contact")
def Contact():
    return render_template("contact.html")

@app.route('/about')
def About():
    return render_template("about.html")

@app.errorhandler(404)
def Page_not_found(e):
    return render_template('404.html')

@app.errorhandler(500)
def internal_server_error(e):
    return render_template('500.html')

@app.route('/login',methods=['GET','POST'])
def Login():
    Form=LoginForm()
    if request.method=="POST":
        if Form.validate_on_submit():
            user=UserInfo.query.filter_by(username=Form.username.data).first()
            if user:
                if Form.password.data==user.password:
                    login_user(user)
                    return redirect(url_for('Index'))
                flash("Invalid Credentials")
    return render_template('login.html',title="Login",form=Form)

@app.route("/signup",methods=["GET",'POST'])
def SignUp():
    Form=SignupForm()
    if Form.validate_on_submit():
        username=Form.Name.data
        password=Form.Password.data
        confirm_password=Form.Confirm_Password.data
        # DOB=Form.DOB.data
        email=Form.Email.data
        new_user=UserInfo(username,password,confirm_password,email)
        db.session.add(new_user)
        db.session.commit()
        flash("Successfully Created Your Account")
        return redirect(url_for("Login"))
    return render_template("signup.html",title="SignUp",form=Form)
