# In View.py we are add All Input Fields Data
from flask_wtf import Form,FlaskForm
from wtforms import StringField,PasswordField,DateField
from wtforms.validators import InputRequired

class LoginForm(FlaskForm):

    username = StringField("username",validators=[InputRequired()],render_kw={"placeholder": "username"})
    password = PasswordField("password",validators=[InputRequired()],render_kw={"placeholder": "password"})

class SignupForm(FlaskForm):
    Name=StringField('Full Name',validators=[InputRequired()],render_kw={"placeholder": "Full Name"})
    Email=StringField("Email",validators=[InputRequired()],render_kw={"placeholder": "Email"})
    Password=PasswordField("Password",validators=[InputRequired()],render_kw={"placeholder": "Password"})
    Confirm_Password=PasswordField("Confirm Password",validators=[InputRequired()],render_kw={"placeholder": "Confirm Password"})

