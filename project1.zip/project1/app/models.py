#in Model.py we add our database
from app import login_manager
from app import db
from flask_login import UserMixin
class UserInfo(UserMixin,db.Model):
    id=db.Column(db.INTEGER,primary_key=True)
    username=db.Column(db.String(32),unique=True)
    password=db.Column(db.String(32))
    confirm_password=db.Column(db.String(32))
    email=db.Column(db.String(32))

    def __init__(self,username,password,confirm_password,email):
        self.username=username
        self.password=password
        self.confirm_password=confirm_password
        self.email=email
@login_manager.user_loader
def load_user(user_id):
    return UserInfo. query.get(user_id)