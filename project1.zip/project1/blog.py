#in blog.py we run the app
from app import app

app.run(debug=True)