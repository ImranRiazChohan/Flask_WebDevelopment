# here we add secrete key or api configuration

class Config:
    SECRET_KEY = 'hardsecretkey'
    SQLALCHEMY_DATABASE_URI = "sqlite:////Users/chohan/Desktop/Flask_Projects/project1/myflask.db"
    SQLALCHEMY_TRACK_MODIFICATIONS = False
