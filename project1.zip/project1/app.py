# #1:introduction
# #2:Flask URL Routing
# #3:Dynamic URL Routing
# #4:Flask Cookies
# #5:Flask Template
# #6:Flask Templates Inheritance
# #7:Flask Context Variable
# #8 Flask adding Bootstrap
# #9:Custom Error page
# #10:Url Helper Function
# #11:Flask Static Files
# #12:Flask Wtf FORMs
# #13:WTF forms Error messages
# #14:Flask Flask Messages
# #15:flask SqlAlchemy
# #16:flask migrate***
# #17 Flask Folder Structure
# #18: Flask SignupForm
# #19 Flask Login

# from flask import Flask,make_response,request,render_template,redirect,url_for,flash
# from form import LoginForm,SignupForm
# from flask_mysqldb import MySQL
# from flask_sqlalchemy import SQLAlchemy
# from flask_migrate import Migrate,MigrateCommand
# from flask_script import Manager
#
#
# #Create an App
# app=Flask(__name__)
# #create a database
# app.config["SECRET_KEY"]='hardsecretkey'
# # app.config["MYSQL_HOST"]='localhost'
# # app.config["MYSQL_USER"]="root"
# # app.config["MYSQL_PASSWORD"]=""
# # app.config["MYSQL_DB"]="myflask"
# # db=MySQL(app)
#
#
# app.config["SQLALCHEMY_DATABASE_URI"]="sqlite:////Users/chohan/Desktop/Flask_Projects/project1/myflask.db"
# app.config["SQLALCHEMY_TRACK_MODIFICATIONS"]=False
# db=SQLAlchemy(app)
# migrate=Migrate(app,db)
# manager=Manager(app)
#
# manager.add_command('db',MigrateCommand )
# class UserInfo(db.Model):
#     id=db.Column(db.INTEGER,primary_key=True)
#     username=db.Column(db.String(32),unique=True)
#     password=db.Column(db.String(32))
#
#     def __init__(self,username,password):
#         self.username=username
#         self.password=password
#
#
#
# #Create an Route
# @app.route('/')
# def Index():
#
#     return render_template('index.html')
#
# @app.route("/contact")
# def Contact():
#     return render_template("contact.html")
#
# @app.route('/about')
# def About():
#     return render_template("about.html")
# @app.errorhandler(404)
# def Page_not_found(e):
#     return render_template('404.html')
# @app.errorhandler(500)
# def internal_server_error(e):
#     return render_template('500.html')
#
# @app.route('/login',methods=['GET','POST'])
# def Login():
#     Form=LoginForm()
#     if Form.validate_on_submit():
#         if request.form['username']!="usama" or request.form["password"]!="12345":
#             flash("Invalid Credential,Please Try Again")
#         else:
#             return redirect(url_for('Index'))
#
#     return render_template('login.html',title="Login",form=Form)
#
# @app.route("/signup",methods=["GET",'POST'])
# def SignUp():
#     Form=SignupForm()
#     if Form.validate_on_submit():
#         if request.form["Password"]==request.form["Confirm_Password"]:
#             flash("Successfully Created Your Account")
#             return redirect(url_for("Login"))
#     return render_template("signup.html",title="SignUp",form=Form)
#
# #For Running the App
# if __name__=="__main__":
#     app.run(debug=True)
#
#manager.run()
#
# db.session.add(u)
# db.session.commit()